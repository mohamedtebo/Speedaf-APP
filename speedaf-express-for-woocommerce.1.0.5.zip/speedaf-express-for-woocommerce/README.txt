=== Speedaf Express for woocommerce ===
Contributors: Wolf
Tags: express,shipping,speedaf,Speedaf,Express Speedaf,
Requires at least: 5.1
Tested up to: 6.0.1
Requires PHP: 7.4
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Speedaf Plugin is Speedaf's official extension for WooCommerce on WordPress. Manage your shipments easily.

== Description ==
Speedaf Plugin is Speedaf's official extension for WooCommerce on WordPress. Manage your shipments easily.
Fast and easy consignment note creation of your orders.

Easily print out consignment note.

Bulk Consignment Note Creation allows you to create consignment notes for multiple orders.

Bulk Consignment Note Printing allows you to print multiple consignment notes.

Tracking Parcel Status function.
== Installation ==
1. Upload the files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins.

2. Activate the plugin through the `Plugins` menu in WordPress.

3. Done and Ready.

== Frequently Asked Questions ==
= Can I Use This Plugin Without Being A Speedaf  customer number? =

No. You need to be a valid API KEY to use this plugin. You can register to be Speedaf customer at [here](https://csp.speedaf.com/login#/login)


== Screenshots ==



== Changelog ==
* First release.
*Release Date - 23 July 2022*
	> Api key bug fix
*Release Date - 225 July 2022*
	> Api key error notes
	-> Fix Small Code

*Release Date - 9 Sep 2022*
   -> translate language
   -> Updated order Id Rule
