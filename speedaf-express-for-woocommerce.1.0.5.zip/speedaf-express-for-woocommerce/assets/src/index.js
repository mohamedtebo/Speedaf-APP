import * as $ from "jquery";
import {sdfOrder} from "./js/speedaf-admin.min.js";
//import {jConfirm } from "./js/confirm.min.js";

$(function(){
    sdfOrder.init();
})