<?php

declare(strict_types=1);

namespace Wolf\Speedaf\Api;
defined( 'ABSPATH' ) || exit; // block direct access.

interface RegisterInterface
{
    public function register();
    
}
