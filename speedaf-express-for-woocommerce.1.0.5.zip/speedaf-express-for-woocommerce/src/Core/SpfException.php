<?php

declare(strict_types=1);

namespace Wolf\Speedaf\Core;
defined( 'ABSPATH' ) || exit; // block direct access.

class SpfException extends \Exception
{
    
}
